Covid19-Panama
==============

Thesis project which implements statistical models to provide forecasting for COVID-19 cases in Panama.
