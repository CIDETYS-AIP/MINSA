class NoStrategyProvidedException(Exception):
    pass
